export class Product {
  id: number;
  prodCode: string;
  prodCost: number;
  vendorName: String;
  prodGst: number;
}

package in.nareshit.raghu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SringBoot2RestJpaMySqlAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SringBoot2RestJpaMySqlAppApplication.class, args);
	}

}

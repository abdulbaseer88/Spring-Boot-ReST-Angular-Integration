package in.nareshit.raghu.config;

import static springfox.documentation.builders.PathSelectors.regex;
import static springfox.documentation.builders.RequestHandlerSelectors.basePackage;

import java.util.Collections;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerConfig {

	@Bean
	public Docket createDocket() {
		return new Docket(DocumentationType.SWAGGER_2) // Swagger Screen
				.select() // read rest controllers
				.apis(basePackage("in.nareshit.raghu.controller.rest")) // (api)rest controller from common package name
				.paths(regex("/rest.*")) // having one common starting path (/.*)
				.build() //create screen
				.useDefaultResponseMessages(false)
				.apiInfo(apiInfo())
				;
		
	}

	private ApiInfo apiInfo() {
		return new ApiInfo(
				"Product NIT APP", 
				"This is a sample Product Store", 
				"3.2 GA", 
				"https://nareshit.in/", 
				new Contact("Raghu", "http://nareshit.raghu.in/", "javabyraghu@gmail.com"), 
				"NIT Lmtd License", 
				"https://nareshit.in/license", 
				Collections.emptyList());
	}
	
	
}

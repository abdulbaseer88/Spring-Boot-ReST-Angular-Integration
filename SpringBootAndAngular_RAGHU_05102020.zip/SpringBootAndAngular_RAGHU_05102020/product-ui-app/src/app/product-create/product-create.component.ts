import { Component, OnInit } from '@angular/core';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-create',
  templateUrl: './product-create.component.html',
  styleUrls: ['./product-create.component.css'],
})
export class ProductCreateComponent implements OnInit {
  //declare form object
  product: Product;
  message: any;

  //inject service
  constructor(private service: ProductService) {}

  ngOnInit(): void {
    //initialize JSON object with defaults
    this.product = new Product();
  }

  // on click submit button
  createProduct() {
    this.service.createProduct(this.product).subscribe(
      (data) => {
        this.message = data;
        this.product = new Product();
      },
      (error) => {
        console.log(error);
      }
    );
  }
}

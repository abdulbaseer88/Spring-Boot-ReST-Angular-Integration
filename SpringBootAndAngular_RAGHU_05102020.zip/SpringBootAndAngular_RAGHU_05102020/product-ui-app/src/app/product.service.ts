import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from './product';

@Injectable({
  providedIn: 'root',
})
export class ProductService {
  baseUrl = 'http://localhost:8080/rest/product';

  // dependency injection
  constructor(private http: HttpClient) {}

  getAllProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.baseUrl}/all`);
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.baseUrl}/remove/${id}`, {
      responseType: 'text',
    });
  }

  createProduct(product: Product): Observable<any> {
    return this.http.post(`${this.baseUrl}/save`, product, {
      responseType: 'text',
    });
  }

  getOneProduct(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.baseUrl}/find/${id}`);
  }

  updateProduct(id: number, product: Product):Observable<any> {
    return this.http.put(`${this.baseUrl}/modify/${id}`,product, {responseType: 'text'});
  }
}

import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Product } from '../product';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css'],
})
export class ProductListComponent implements OnInit {
  //vaiable
  products: Product[];
  message: any;

  //inject service
  constructor(private service: ProductService, private router:Router) {}

  ngOnInit(): void {
    this.getAllProducts();
  }

  getAllProducts() {
    this.service.getAllProducts().subscribe(
      (data) => {
        //on success
        this.products = data;
      },
      (error) => {
        //on fail
        console.log(error);
      }
    );
  }

  deleteProduct(id: number) {
    if (confirm('Do you want to delete :' + id)) {
      this.service.deleteProduct(id).subscribe(
        (data) => {
          this.message = data;
          //re load new data
          this.getAllProducts();
        },
        (error) => {
          console.log(error);
        }
      );
      //console.log('Deleted' + id);
    } else {
      this.message = 'Delete Operation is Cancelled';
      //console.log('Deleted cancelled :' + id);
    }
  }

  editProduct(id:number) {
    //console.log(id);
    this.router.navigate(['edit',id]);
  }
}
